package com.example.euapp16.myapplication.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.euapp16.myapplication.user.User;

import java.util.ArrayList;

/**
 * Created by erasmus on 10.11.2017.
 */

public final class Model {
    private final Helper helper;

    private final SQLiteDatabase database;

    public static final String COL_USER_ID = "user_id";
    public static final String COL_USER_NAME = "user_name";
    public static final String COL_USER_SURNAME = "user_surname";
    public static final String COL_USER_AGE = "user_age";
    public static final String COL_USER_EMAIL = "user_email";
    public static final String COL_USER_PASSWORD = "user_password";
    public static final String TABLE_NAME = "user_registration";


    public Model(Context context) {
        helper = new Helper(context);
        database = helper.getWritableDatabase();
    }

    public void addUser(String name, String surname, String age, String email, String password) {
        String SQL = String.format("INSERT INTO %s (%s, %s, %i, %s, %s) VALUES (?, ?, ?, ?, ?"),
                TABLE_NAME, COL_USER_NAME, COL_USER_SURNAME, COL_USER_AGE, COL_USER_EMAIL, COL_USER_PASSWORD;
        database.execSQL(SQL, new String [] {name, surname, age, email, password});

    }

    public ArrayList<User> fetchAllUsers(){
        ArrayList<User> arrayList = new ArrayList<>();

        String SQL = String.format("SELECT %s, %s, %s, %s FROM %S",
                COL_USER_ID, COL_USER_NAME, COL_USER_EMAIL, COL_USER_PASSWORD);

        Cursor cursor = database.rawQuery(SQL, new String[] {});

        if (cursor.moveToFirst()){
            do {
                arrayList.add(new User(cursor));
            } while (cursor.moveToNext());
        }
        return arrayList;
    }
}
