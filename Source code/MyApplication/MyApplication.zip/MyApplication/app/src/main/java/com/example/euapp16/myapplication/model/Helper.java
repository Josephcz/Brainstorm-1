package com.example.euapp16.myapplication.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by erasmus on 10.11.2017.
 */


final class Helper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Brainstorm";
    private static final int DATABE_VERSION = 1;

    public Helper(Context context) {
        super(context, DATABASE_NAME, null, DATABE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE user(user_id INT PRIMARY KEY AUTO_INCREMENT, name TEXT, surname TEXT, age INT, email TEXT, password TEXT, school_idschool INT, permision_idpermision INT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}