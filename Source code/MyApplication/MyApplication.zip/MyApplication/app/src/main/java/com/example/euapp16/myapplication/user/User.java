package com.example.euapp16.myapplication.user;

import android.database.Cursor;

import com.example.euapp16.myapplication.model.Model;

/**
 * Created by erasmus on 10.11.2017.
 */

public final class User {
    public final int id;
    public final String name;
    public final String email;
    public final String password;

    public User(Cursor cursor){
        int id_index = cursor.getColumnIndex(Model.COL_USER_ID);
        int author_index = cursor.getColumnIndex(Model.COL_USER_NAME);
        int email_index = cursor.getColumnIndex(Model.COL_USER_EMAIL);
        int password_index = cursor.getColumnIndex(Model.COL_USER_PASSWORD);

        id = cursor.getInt(id_index);
        name = cursor.getString(author_index);
        email = cursor.getString(email_index);
        password = cursor.getString(password_index);

    }
}
